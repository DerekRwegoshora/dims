<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Pharmacist: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
	</head>

	<body>
	<div class="main">
    <div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

    <div class="navbar" >

			<a href="normaluser.php" class="navbar">Home</a>

					<div class="dropdown">
						<button class="dropbtn">Drugs</button>
						<div class="dropdownmenu">
							<a href="inventoryform2.php">Add Drugs</a>
							<a href="retrieve2drugs.php">Manage Drugs</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Users</button>
						<div class="dropdownmenu">
							<a href="retrieve2users.php">View Users</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Prescriptions</button>
						<div class="dropdownmenu">
							<a href="prescriptionform.php">Add Prescriptions</a>
							<a href="viewprescription2.php">Manage Prescriptions</a>
						</div>
					</div>

					<a href="report/filter_report2.php" class="navbar">Reports</a>

					<div id="username">
						<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
					</div>

		</div>


		<div class="content">
			<div class="sidenav">

				<a href="messageform.php">Message Admin</a>

        <a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

      </div>

		<div class="column1">

			<?php

				//create the connection
				$connection=mysqli_connect("localhost", "root", "", "dit2");

				if(isset($_POST['submitbutn'])) {
					//create the variables
					$customername=$_POST['customername'];
					$drugname=$_POST['drugname'];
					$strength=$_POST['strength'];
					$dose=$_POST['dose'];
					$status=$_POST['status'];
					$quantity=$_POST['quantity'];

		    // checking empty fields
		    if(empty($customername) || empty($drugname) || empty($strength) || empty($dose) || empty($status) || empty($quantity)) {
		        if(empty($customername)) {
		            echo "<font color='red'>Customer Name field is empty.</font><br/>";
		        }

		        if(empty($drugname)) {
		            echo "<font color='red'>Drug Name field is empty.</font><br/>";
		        }

		        if(empty($strength)) {
		            echo "<font color='red'>Strength field is empty.</font><br/>";
		        }

		        if(empty($dose)) {
		            echo "<font color='red'>Dose field is empty.</font><br/>";
		        }

						if(empty($status)) {
		            echo "<font color='red'>Status field is empty.</font><br/>";
		        }

						if(empty($quantity)) {
		            echo "<font color='red'>Quantity field is empty.</font><br/><br/>";
		        }

								header("refresh:7;url=prescriptionform.php");

		    } else {
					//query that will take user data and insert into db
					$query1=mysqli_query($connection,"insert into prescription(customername, drugname, strength, dose, status, quantity) values('$customername', '$drugname', '$strength', '$dose', '$status', '$quantity')");
					if(!$query1){
						echo "<font color='red'>Record Entry Unsuccessful.</font> <br/>";
					}
					else{
						echo "<font color='red'>Record is Successfully Submitted.</font>";

								$test="SELECT * FROM inventory_list WHERE drugname LIKE '%$drugname%'";
								$over=mysqli_query($connection,$test);
								if(mysqli_num_rows($over)==1){
										mysqli_query($connection,"UPDATE inventory_list SET drugquantity=drugquantity-'$quantity' WHERE drugname='$drugname'") or die(mysqli_error());
								}
								header( "refresh:2;url=viewprescription2.php" );
							}
		    		}
				}
		?>

		</div>

	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>
	</body>

</html>
