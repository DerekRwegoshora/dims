-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2019 at 06:08 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dit2`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventory_list`
--

CREATE TABLE IF NOT EXISTS `inventory_list` (
  `drugindex` int(255) NOT NULL AUTO_INCREMENT,
  `drugname` varchar(255) NOT NULL,
  `drugquantity` varchar(255) NOT NULL,
  `drugcategory` varchar(255) NOT NULL,
  `treats` varchar(255) NOT NULL,
  `expirydate` date NOT NULL,
  `initialprice` varchar(255) NOT NULL,
  `saleprice` varchar(255) NOT NULL,
  PRIMARY KEY (`drugindex`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `inventory_list`
--

INSERT INTO `inventory_list` (`drugindex`, `drugname`, `drugquantity`, `drugcategory`, `treats`, `expirydate`, `initialprice`, `saleprice`) VALUES
(1, 'singulair', '235', 'tablets', 'asthma', '2021-10-08', '1100', '1500'),
(2, 'crestor', '210', 'tablets', 'cholesterol', '2022-03-04', '1800', '2500'),
(3, 'zyprexa', '250', 'tablets', 'schizophrenia', '2022-03-04', '3000', '4000'),
(4, 'diovan', '240', 'tablets', 'high bp', '2023-01-01', '2500', '3000'),
(5, 'lantus', '47', 'injection', 'diabetes', '2022-02-02', '5000', '6500'),
(6, 'nexium', '190', 'capsules', 'heart burn', '2021-02-02', '1000', '1500'),
(7, 'panadol', '240', 'tablets', 'painkiller', '2022-02-02', '800', '1000'),
(8, 'herceptin', '70', 'injection', 'chemotherapy', '2020-01-01', '25000', '30000'),
(9, 'azythromycin', '82', 'tablets', 'bacterial infections', '2021-02-02', '1100', '1500'),
(10, 'plavix', '50', 'tablets', 'stroke prevention', '2021-02-02', '2500', '3000'),
(11, 'remicade', '100', 'injection', 'crohns disease', '2021-02-02', '7500', '10000'),
(12, 'advair', '50', 'other', 'asthma', '2022-01-01', '4000', '5000'),
(13, 'lipitor', '50', 'tablets', 'cholesterol', '2021-02-02', '5500', '6500'),
(14, 'flagyl', '479', 'tablets', 'bacterial infections', '2022-01-01', '1300', '1500'),
(15, 'albendazole', '240', 'tablets', 'bacterial infections', '2022-02-02', '800', '1500');

-- --------------------------------------------------------

--
-- Table structure for table `message_details`
--

CREATE TABLE IF NOT EXISTS `message_details` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `message` varchar(500) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `message_details`
--

INSERT INTO `message_details` (`id`, `message`, `sender`, `date`) VALUES
(1, 'Test message to Admin', 'richard', '2019-07-11 14:53:57'),
(2, 'Test Message from James', 'james', '2019-07-11 14:54:23'),
(3, 'Mary has sent a message to the Admin', 'mary', '2019-07-11 14:58:22'),
(4, 'Hello...from the other side', 'mary', '2019-07-11 17:18:33'),
(5, 'Mary says Hi...', 'richard', '2019-07-11 18:17:05'),
(6, 'Friday message testing...', 'richard', '2019-07-12 03:27:18'),
(7, 'Another message from...', 'mary', '2019-07-12 08:20:02');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE IF NOT EXISTS `prescription` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `customername` varchar(255) NOT NULL,
  `drugname` varchar(255) NOT NULL,
  `strength` varchar(255) NOT NULL,
  `dose` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `customername`, `drugname`, `strength`, `dose`, `status`, `quantity`, `date`) VALUES
(1, 'Samson', 'flagyl', '10mg', '1x2', 'full dose', 10, '2019-07-06 09:43:59'),
(2, 'Abdulrazak', 'flagyl', '15mg', '1x1', 'partial dose', 5, '2019-07-06 09:44:42'),
(3, 'Huey', 'plavix', '25mg', '2x2', 'full dose', 15, '2019-07-06 09:45:50'),
(4, 'Arnold', 'singulair', '25mg', '2x2', 'partial dose', 10, '2019-07-11 14:44:09'),
(5, 'Kevin', 'flagyl', '10mg', '1x1', 'full dose', 6, '2019-07-11 14:59:20'),
(6, 'Solomon', 'albendazole', '25mg', '2x2', 'partial dose', 5, '2019-07-11 15:00:13'),
(7, 'Thomas', 'azythromycin', '25mg', '2x2', 'full dose', 18, '2019-07-11 18:23:15'),
(8, 'John', 'lantus', '30ml', '1x1', 'partial dose', 3, '2019-07-11 18:24:51'),
(9, 'Rachel', 'singulair', '25mg', '2x2', 'partial dose', 5, '2019-07-12 07:42:42'),
(10, 'Jack', 'crestor', '25mg', '2x2', 'partial dose', 10, '2019-07-12 10:06:33');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `indexno` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`indexno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`indexno`, `username`, `password`, `email`, `role`) VALUES
(1, 'derek', 'derek', 'derek@gmail.com', 'admin'),
(2, 'james', 'james', 'james@yahoo.com', 'normal'),
(3, 'mary', 'mary', 'mary@gmail.com', 'normal'),
(4, 'richard', 'rich', 'richard@outlook.com', 'normal'),
(5, 'susan', 'susan', 'susan@gmx.com', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
