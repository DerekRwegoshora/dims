<?php
session_start();

	if(isset($_SESSION['username'])){
		$username=$_SESSION['username'];

		$connection=mysqli_connect("localhost","root","","dit2");
		$query1=mysqli_query($connection,"SELECT role FROM user WHERE username='$username' limit 1");
		$data=mysqli_fetch_array($query1);

			$role=$data['role'];
			$_SESSION["role"]=$role;

				if($role=="admin"){
						header("location:adminuser.php");
					}
					else if($role=="normal"){
					header("location:normaluser.php");
			}
}
?>
