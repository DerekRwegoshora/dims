<?php
session_start();
$connection=mysqli_connect("localhost", "root", "", "dit2");

$id=$_GET[indexno];
$sql="delete from user where indexno='$id'";
mysqli_query($connection, $sql);

//$rows=mysql_fetch_assoc($result);
header("location:retrieve1users.php");
?>
