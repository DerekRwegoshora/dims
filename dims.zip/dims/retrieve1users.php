<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
		<link rel="stylesheet" type="text/css" href="style/table.css" />
		<script src="js/sorttable.js"></script>
	</head>

  <body>
		<div class="main">
		<div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

		<div class="navbar" >

			<a href="adminuser.php" class="navbar">Home</a>

				<div class="dropdown">
					<button class="dropbtn">Drugs</button>
					<div class="dropdownmenu">
						<a href="inventoryform1.php">Add Drugs</a>
						<a href="retrieve1drugs.php">Manage Drugs</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Users</button>
					<div class="dropdownmenu">
						<a href="adduserform.php">Add Users</a>
						<a href="retrieve1users.php">Manage Users</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Prescriptions</button>
					<div class="dropdownmenu">
						<a href="viewprescription1.php">View Prescriptions</a>
					</div>
				</div>

				<a href="report/filter_report.php" class="navbar">Reports</a>

				<div id="username">
					<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
				</div>

		</div>


	<div class="content">
		<div class="sidenav">

			<a href="viewmessage.php">Messages</a>

			<a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

		</div>

		<div class="column1">

			<table border="0px" cellpadding="5px" class="sortable" style="font-size:16px">
			<?php
					$connection=mysqli_connect("localhost","root","","dit2");

					$query1=mysqli_query($connection,"SELECT * from user");

					$number_of_rows=mysqli_num_rows($query1);
			?>
			<?php echo "<span><strong>View and Manage Users</strong></span> ($number_of_rows available)<hr/>"; ?>
			<?php
			if(mysqli_num_rows($query1)>0)
					{
			?>
					<tr class="theader"><th>ID</th><th>Username</th><th>Password</th><th>Email</th><th>Role</th>
						<th class="sorttable_nosort">Edit</th><th class="sorttable_nosort">Delete</th></tr>
			<?php
					}
            // selecting rows
            $sql = "SELECT * FROM user ORDER BY indexno ASC";
            $result = mysqli_query($connection,$sql);
            while($array = mysqli_fetch_array($result)){
							$indexno=$array['indexno'];
							$username=$array['username'];
							$password=$array['password'];
							$email=$array['email'];
							$role=$array['role'];

			?>
					<tr>
							<td width="6%"><?php echo "$indexno"; ?></td>
							<td width="22%"><?php echo "$username"; ?></td>
							<td width="22%"><?php echo "$password"; ?></td>
							<td width="22%"><?php echo "$email"; ?></td>
							<td width="15%"><?php echo "$role"; ?></td>
							<?php echo '<td width="7%"><a href="edituser.php? indexno=' . $array['indexno'] . '"><button>Edit</button></a></td> ';?>
							<?php echo '<td width="7%"><a href="deleteuser.php? indexno=' . $array['indexno'] . '"><button Onclick="return confirmation()">Delete</button></a></td> ';?>
								<script>
										function confirmation() {
									  var result = confirm("Are you sure?");
									  if (result==true) {
									   return true;
									  } else {
									   return false;
									  }
									}
								</script>
					</tr>

			<?php
					}
			?>
			</table>
		</div>
	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>
	</body>

</html>
