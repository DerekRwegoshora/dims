<?php
//include connection file
include_once('fpdf/fpdf.php');
include_once("connection.php");

class PDF extends FPDF
{
// Page header
function Header()
{
// Arial italic 8
$this->SetFont('Arial','B',12);
// Title
$this->Cell(32,20,'Inventory List',0,0,'J');
// Line break
$this->Ln(15);
}

// Page footer
function Footer()
{
// Position at 1.5 cm from bottom
$this->SetY(-15);
// Arial italic 8
$this->SetFont('Arial','I',9);
// Page number
$this->Cell(0,6,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

$db = new dbObj();
$connString =  $db->getConnstring();
$display_heading = array('drugindex'=>'ID', 'drugname'=> 'Drug Name', 'drugquantity'=> 'Quantity-left', 'drugcategory'=> 'Category', 'treats'=> 'Treatment', 'expirydate'=> 'Exp-Date',
'initialprice'=> 'Buy-Price', 'saleprice'=> 'Sale-Price');

$result = mysqli_query($connString, "SELECT drugindex,drugname,drugquantity,drugcategory,treats,expirydate,initialprice,saleprice FROM inventory_list") or die("database error:". mysqli_error($connString));
$header = mysqli_query($connString, "SHOW columns FROM inventory_list");

$pdf = new PDF('L', 'mm', 'Letter');
//header
$pdf->AddPage();
//footer page
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',10);
foreach($header as $heading) {
$pdf->setFillColor(223, 223, 223);
$pdf->Cell(32,10,$display_heading[$heading['Field']],1,0,'J',TRUE);
}
$pdf->SetFont('Arial','B',9);
foreach($result as $row) {
$pdf->Ln();
foreach($row as $column)
$pdf->Cell(32,10,$column,1);
}
$pdf->Output('full_list.pdf', 'I');
?>
