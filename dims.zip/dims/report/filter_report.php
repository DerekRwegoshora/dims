<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
		<link rel="stylesheet" type="text/css" href="style/table.css" />
	</head>

	<body>
		<div class="main">
		<div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

		<div class="navbar" >

			<a href="../adminuser.php" class="navbar">Home</a>

				<div class="dropdown">
					<button class="dropbtn">Drugs</button>
					<div class="dropdownmenu">
						<a href="../inventoryform1.php">Add Drugs</a>
						<a href="../retrieve1drugs.php">Manage Drugs</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Users</button>
					<div class="dropdownmenu">
						<a href="../adduserform.php">Add Users</a>
						<a href="../retrieve1users.php">Manage Users</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Prescriptions</button>
					<div class="dropdownmenu">
						<a href="../viewprescription1.php">View Prescriptions</a>
					</div>
				</div>

				<a href="filter_report.php" class="navbar">Reports</a>

				<div id="username">
					<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
				</div>

		</div>


	<div class="content">
		<div class="sidenav">

			<a href="../viewmessage.php">Messages</a>

			<a href="../logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

		</div>

		<div class="column1">
			<span><strong>Generate Inventory Reports</strong></span>
			<hr/>

			<ul type="disc">
				<li>A list of drugs that are <strong>below</strong> a certain quantity e.g. 50, 100, 150...</li>
			</ul>

			<div class="entrytable">
				<table cellspacing="2px" padding="10px" class="mytable">
					<form action="filter_report.php" method="post" target="_blank">
						<tr><td><select name="filterdrug" /required><option value="" disabled selected hidden>Filter Drug Quantity</option>
							<option value="50">Less or Equal to 50</option>
							<option value="100">Less or Equal to 100</option>
							<option value="150">Less or Equal to 150</option></select></td></tr>
						<tr><td align="center"><input type="submit" name="submitbutn" value="PDF" /></td></tr>
					</form>
				</table>

							<?php
									//create the connection
									$connection=mysqli_connect("localhost", "root", "", "dit2");

									if(isset($_POST['submitbutn'])){
										//create the variables
										$filterdrug=$_POST['filterdrug'];

										//query that will take user data and insert into db
										$query1=mysqli_query($connection, "SELECT * FROM inventory_list");
										if(mysqli_num_rows($query1)<=0){
											echo "<font color='red'>Error, Try Again!</font> <br/>";
										}
										else{

											$_SESSION['filterdrug']=$filterdrug;

											echo "<font color='red'>Report is generating...</font>";
											header("location:report.php");
											}
									}
								?>
			</div>
			<ul type="disc">
				<li>A list of ALL available drugs...</li>
			</ul>
			<h4><a href="fullreport.php" target="_blank" class="report">Generate Full List</a></h4>
		</div>
	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>
	</body>

</html>
