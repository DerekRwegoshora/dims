<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
	</head>

	<body>
	<div class="main">
    	<div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

	<div class="navbar" >

		<a href="adminuser.php" class="navbar">Home</a>

			<div class="dropdown">
				<button class="dropbtn">Drugs</button>
				<div class="dropdownmenu">
					<a href="inventoryform1.php">Add Drugs</a>
					<a href="retrieve1drugs.php">Manage Drugs</a>
				</div>
			</div>

			<div class="dropdown">
				<button class="dropbtn">Users</button>
				<div class="dropdownmenu">
					<a href="adduserform.php">Add Users</a>
					<a href="retrieve1users.php">Manage Users</a>
				</div>
			</div>

			<div class="dropdown">
				<button class="dropbtn">Prescriptions</button>
				<div class="dropdownmenu">
					<a href="viewprescription1.php">View Prescriptions</a>
				</div>
			</div>

			<a href="report/filter_report.php" class="navbar">Reports</a>

			<div id="username">
				<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
			</div>

	</div>


<div class="content">
	<div class="sidenav">

				<a href="viewmessage.php">Messages</a>

        <a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

      </div>

		<div class="column1">

			<?php

				//create the connection
				$connection=mysqli_connect("localhost", "root", "", "dit2");

				if(isset($_POST['submitbutn'])) {
					//create the variables
					$username=$_POST['username'];
					$password=$_POST['password'];
					$email=$_POST['email'];
					$role=$_POST['role'];

		    // checking empty fields
		    if(empty($username) || empty($password) || empty($email) || empty($role)) {
		        if(empty($username)) {
		            echo "<font color='red'>Username field is empty.</font><br/>";
		        }

		        if(empty($password)) {
		            echo "<font color='red'>Password field is empty.</font><br/>";
		        }

		        if(empty($email)) {
		            echo "<font color='red'>Email field is empty.</font><br/>";
		        }

		        if(empty($role)) {
		            echo "<font color='red'>Role field is empty.</font><br/><br/><br/>";
		        }

								header("refresh:7;url=adduserform.php");

		    } else {
					//query that will take user data and insert into db
					$query1=mysqli_query($connection, "insert into user(username, password, email, role) values('$username', '$password', '$email', '$role')");

					if(!$query1){
						echo "<font color='red'>User Entry Unsuccessful.</font> <br/>";
					}
					else{
						echo "<font color='red'>User is Successfully Added.</font>";
						header( "refresh:2;url=retrieve1users.php" );
					}
		    }
		}

			?>

		</div>

	</body>

	<body>
	</div>		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>

	</body>

</html>
