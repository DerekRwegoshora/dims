<?php
session_start();
$connection=mysqli_connect("localhost", "root", "", "dit2");

$id=$_GET[drugindex];
$sql="delete from inventory_list where drugindex='$id'";
mysqli_query($connection, $sql);

//$rows=mysql_fetch_assoc($result);
header("location:retrieve1drugs.php");
?>
