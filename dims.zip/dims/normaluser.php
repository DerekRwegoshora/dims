<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Pharmacist: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
	</head>

	<body>
			<div class="main">
		<div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

		<div class="navbar" >

			<a href="normaluser.php" class="navbar">Home</a>

					<div class="dropdown">
						<button class="dropbtn">Drugs</button>
						<div class="dropdownmenu">
							<a href="inventoryform2.php">Add Drugs</a>
							<a href="retrieve2drugs.php">Manage Drugs</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Users</button>
						<div class="dropdownmenu">
							<a href="retrieve2users.php">View Users</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Prescriptions</button>
						<div class="dropdownmenu">
							<a href="prescriptionform.php">Add Prescriptions</a>
							<a href="viewprescription2.php">Manage Prescriptions</a>
						</div>
					</div>

					<a href="report/filter_report2.php" class="navbar">Reports</a>

					<div id="username">
						<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
					</div>

		</div>


		<div class="content">
			<div class="sidenav">

				<a href="messageform.php">Message Admin</a>

				<a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

			</div>

			<div class="column1">

			<?php

				if (!isset($_SESSION['username'])){
					header("location:login.php");
				}

				else{
					$username=$_SESSION['username'];
					$role=$_SESSION['role'];

					if($role!="normal"){
						echo"<font color='red'>YOU ARE TRESPASSING!!!</font>";
						header("location:login.php");
					}
					else{
						$state="Pharmacist: $username";
				?>
							<a href="normaluser.php" class="dashboard">
								<img src="icons/pharmacist_icon.png" width="75" height="75" alt="edit" />
								<span><strong><?php echo "$state"; ?></strong></span>
							</a>

					<?php
						 }
					}

				?>
					<a href="retrieve2drugs.php" class="dashboard">
						<img src="icons/inventory_icon.png"  width="75" height="75" alt="edit" />
						<span>Drugs</span>
					</a>

					<a href="retrieve2users.php" class="dashboard">
						<img src="icons/user_icon.png"  width="75" height="75" alt="edit" />
						<span>Users</span>
					</a>

					<a href="viewprescription2.php" class="dashboard">
						<img src="icons/prescri_icon.png"  width="75" height="75" alt="edit" />
						<span>Prescriptions</span>
					</a>

					<a href="report/filter_report2.php" class="dashboard">
						<img src="icons/report_icon.png"  width="75" height="75" alt="edit" />
						<span>Reports</span>
					</a>

			</div>
	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>
	</body>

</html>
