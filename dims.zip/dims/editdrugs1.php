<?php
	session_start();
  function renderForm($drugindex, $drugname, $drugquantity, $drugcategory, $treats, $expirydate, $initialprice, $saleprice, $error){
		if(isset($_SESSION['username'])){
		$user=$_SESSION['username'];
		$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
		<link rel="stylesheet" type="text/css" href="style/table.css" />
	</head>

	<body>
	<div class="main">

		<div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

    	<div class="navbar" >

				<a href="adminuser.php" class="navbar">Home</a>

					<div class="dropdown">
						<button class="dropbtn">Drugs</button>
						<div class="dropdownmenu">
							<a href="inventoryform1.php">Add Drugs</a>
							<a href="retrieve1drugs.php">Manage Drugs</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Users</button>
						<div class="dropdownmenu">
							<a href="adduserform.php">Add Users</a>
							<a href="retrieve1users.php">Manage Users</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Prescriptions</button>
						<div class="dropdownmenu">
							<a href="viewprescription1.php">View Prescriptions</a>
						</div>
					</div>

					<a href="report/filter_report.php" class="navbar">Reports</a>

					<div id="username">
						<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
					</div>

			</div>


		<div class="content">
			<div class="sidenav">

				<a href="viewmessage.php">Messages</a>

        <a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

      </div>

		<div class="column1">
			<span><strong>Edit Drugs</strong></span>
			<hr/>
          <?php
            if ($error!=''){
              echo '<div style="padding:4px; color:red;">'.$error.'</div>';
            } ?>
				<div class="entrytable">
					<table cellspacing="2px" padding="10px" class="mytable">
						<form name="form1" action="editdrugs1.php" method="post">
		            <input type="hidden" name="drugindex" value="<?php echo $drugindex; ?>"/>
		          <tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: Albendazole"/><input type="text" name="drugname" placeholder="Drug Name" size="30%" value="<?php echo $drugname; ?>" /></td></tr>
							<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: 1500"/><input type="text" name="drugquantity" placeholder="Quantity" size="30%" value="<?php echo $drugquantity; ?>" /></td></tr>
							<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: capsules"/><select name="drugcategory" value="<?php echo $drugcategory; ?>" /required><option value="" disabled selected hidden>Choose Drug Category</option>
								<option value="tablets">tablets</option><option value="capsules">capsules</option><option value="syrup">syrup</option><option value="injection">injection</option><option value="other">other</option></select></td></tr>
							<tr><td><img src="icons/info_icon.png" height="12px" width="12px" title="Example: asthma"/><input type="text" name="treats" placeholder="Treats..." size="30%" value="<?php echo $treats; ?>" /></td></tr>
							<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: 2020/08/10"/><input type="datetime" name="expirydate" placeholder="Exp Date" size="30%" value="<?php echo $expirydate; ?>" /></td></tr>
							<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: 1200"/><input type="text" name="initialprice" placeholder="Init Price" size="30%" value="<?php echo $initialprice; ?>" /></td></tr>
							<tr><td align="center"> <img src="icons/info_icon.png" height="12px" width="12px" title="Example: 1500"/><input type="text" name="saleprice" placeholder="Sale Price" size="30%" value="<?php echo $saleprice; ?>" /></td></tr>
							<tr><td align="center"><input type="submit" name="submitbutn" value="Submit" /></td></tr>
						</form>
					</table>
				</div>
		</div>

	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>

	</body>

</html>

<?php
  }

  //create the connection
  $connection=mysqli_connect("localhost", "root", "", "dit2");

  if (isset($_POST['submitbutn'])){
    // confirm that the 'id' value is a valid integer before getting the form data
    if (is_numeric($_POST['drugindex'])){
      // get form data, making sure it is valid
        $drugindex=$_POST['drugindex'];
        $drugname=mysql_real_escape_string(htmlspecialchars($_POST['drugname']));
        $drugquantity=mysql_real_escape_string(htmlspecialchars($_POST['drugquantity']));
        $drugcategory=mysql_real_escape_string(htmlspecialchars($_POST['drugcategory']));
				$treats=mysql_real_escape_string(htmlspecialchars($_POST['treats']));
        $expirydate=mysql_real_escape_string(htmlspecialchars($_POST['expirydate']));
				$initialprice=mysql_real_escape_string(htmlspecialchars($_POST['initialprice']));
				$saleprice=mysql_real_escape_string(htmlspecialchars($_POST['saleprice']));

        // check that firstname/lastname fields are both filled in
        if ($drugname=='' || $drugquantity=='' || $drugcategory==''  || $treats=='' || $expirydate=='' || $initialprice=='' || $saleprice==''){
          $error = 'Please fill in all required fields!';
          renderForm($drugindex, $drugname, $drugquantity, $drugcategory, $treats, $expirydate, $initialprice, $saleprice, $error);
        }else{
          mysqli_query($connection,"UPDATE inventory_list SET drugname='$drugname', drugquantity='$drugquantity', drugcategory='$drugcategory', treats='$treats', expirydate='$expirydate', initialprice='$initialprice', saleprice='$saleprice' WHERE drugindex='$drugindex'") or die(mysqli_error());

          // once saved, redirect back to the view page
          header("refresh:1;url=retrieve1drugs.php");
        }
      }else{
        echo 'Error!';
      }
    }else{
    // if the form hasn't been submitted, get the data from the db and display the form
    // get the 'id' value from the URL (if it exists), making sure that it is valid (checing that it is numeric/larger than 0)
    if (isset($_GET['drugindex']) && is_numeric($_GET['drugindex']) && $_GET['drugindex'] > 0){
      // query db
      $drugindex=$_GET['drugindex'];
      $result=mysqli_query($connection,"SELECT * FROM inventory_list WHERE drugindex=$drugindex") or die(mysql_error());
      $row=mysqli_fetch_array($result);
      if($row){
				$drugname=$row['drugname'];
        $drugquantity=$row['drugquantity'];
        $drugcategory=$row['drugcategory'];
				$treats=$row['treats'];
        $expirydate=$row['expirydate'];
				$initialprice=$row['initialprice'];
				$saleprice=$row['saleprice'];
        renderForm($drugindex, $drugname, $drugquantity, $drugcategory, $treats, $expirydate, $initialprice, $saleprice, '');
      }else{
        echo "No results!";
      }
    }else{
    // if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error
      echo 'Error!';
    }
}

?>
