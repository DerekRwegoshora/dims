<?php
	session_start();
  function renderForm($indexno, $username, $password, $email, $role, $error){
		if(isset($_SESSION['username'])){
		$user=$_SESSION['username'];
		$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
		<link rel="stylesheet" type="text/css" href="style/table.css" />
	</head>

	<body>
	<div class="main">

		<div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

    	<div class="navbar" >

				<a href="adminuser.php" class="navbar">Home</a>

					<div class="dropdown">
						<button class="dropbtn">Drugs</button>
						<div class="dropdownmenu">
							<a href="inventoryform1.php">Add Drugs</a>
							<a href="retrieve1drugs.php">Manage Drugs</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Users</button>
						<div class="dropdownmenu">
							<a href="adduserform.php">Add Users</a>
							<a href="retrieve1users.php">Manage Users</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Prescriptions</button>
						<div class="dropdownmenu">
							<a href="viewprescription1.php">View Prescriptions</a>
						</div>
					</div>

					<a href="report/filter_report.php" class="navbar">Reports</a>

					<div id="username">
						<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
					</div>

			</div>


		<div class="content">
			<div class="sidenav">

				<a href="viewmessage.php">Messages</a>

        <a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

      </div>

		<div class="column1">
			<span><strong>Edit User</strong></span>
			<hr/>
          <?php
            if ($error!=''){
              echo '<div style="padding:4px; border:1px solid red; color:red;">'.$error.'</div>';
            } ?>
				<div class="entrytable">
					<table cellspacing="2px" padding="10px" class="mytable">
						<form name="form1" action="edituser.php" method="post">
		            <input type="hidden" name="indexno" value="<?php echo $indexno; ?>"/>
		          <tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: Susan"/><input type="text" name="username" placeholder="Username" value="<?php echo $username; ?>" /></td></tr>
							<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: 12345"/><input type="password" name="password" placeholder="User Password" value="<?php echo $password; ?>" /></td></tr>
							<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: susan@yahoo.com"/><input type="email" name="email" placeholder="User Email" value="<?php echo $email; ?>" /></td></tr>
							<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: Admin"/><select name="role" /required><option value="" disabled selected hidden>Choose Role</option><option value="admin">admin</option><option value="normal">normal</option></select>
							<tr><td align="center"><input type="submit" name="submitbutn" value="Submit" /></td></tr>
						</form>
					</table>
				</div>
		</div>

	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>

	</body>

</html>

<?php
  }

  //create the connection
  $connection=mysqli_connect("localhost", "root", "", "dit2");

  if (isset($_POST['submitbutn'])){
    // confirm that the 'id' value is a valid integer before getting the form data
    if (is_numeric($_POST['indexno'])){
      // get form data, making sure it is valid
        $indexno=$_POST['indexno'];
        $username=mysql_real_escape_string(htmlspecialchars($_POST['username']));
        $password=mysql_real_escape_string(htmlspecialchars($_POST['password']));
        $email=mysql_real_escape_string(htmlspecialchars($_POST['email']));
        $role=mysql_real_escape_string(htmlspecialchars($_POST['role']));

        // check that firstname/lastname fields are both filled in
        if ($username=='' || $password=='' || $email=='' || $role==''){
          $error = 'Please fill in all required fields!';
          renderForm($indexno, $username, $password, $email, $role, $error);
        }else{
          mysqli_query($connection,"UPDATE user SET username='$username', password='$password', email='$email', role='$role' WHERE indexno='$indexno'") or die(mysqli_error());

          // once saved, redirect back to the view page
					header("refresh:1;url=retrieve1users.php");
        }
      }else{
        echo 'Error!';
      }
    }else{
    // if the form hasn't been submitted, get the data from the db and display the form
    // get the 'id' value from the URL (if it exists), making sure that it is valid (checing that it is numeric/larger than 0)
    if (isset($_GET['indexno']) && is_numeric($_GET['indexno']) && $_GET['indexno'] > 0){
      // query db
      $indexno=$_GET['indexno'];
      $result=mysqli_query($connection,"SELECT * FROM user WHERE indexno=$indexno") or die(mysql_error());
      $row=mysqli_fetch_array($result);
      if($row){
        $username=$row['username'];
        $password=$row['password'];
        $email=$row['email'];
        $role=$row['role'];
        renderForm($indexno, $username, $password, $email, $role, '');
      }else{
        echo "No results!";
      }
    }else{
    // if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error
      echo 'Error!';
    }
}

?>
