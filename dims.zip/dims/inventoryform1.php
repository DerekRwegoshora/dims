<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
		<link rel="stylesheet" type="text/css" href="style/table.css" />
	</head>

	<body>
	<div class="main">
    <div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

    <div class="navbar" >

			<a href="adminuser.php" class="navbar">Home</a>

				<div class="dropdown">
					<button class="dropbtn">Drugs</button>
					<div class="dropdownmenu">
						<a href="inventoryform1.php">Add Drugs</a>
						<a href="retrieve1drugs.php">Manage Drugs</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Users</button>
					<div class="dropdownmenu">
						<a href="adduserform.php">Add Users</a>
						<a href="retrieve1users.php">Manage Users</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Prescriptions</button>
					<div class="dropdownmenu">
						<a href="viewprescription1.php">View Prescriptions</a>
					</div>
				</div>

				<a href="report/filter_report.php" class="navbar">Reports</a>

				<div id="username">
					<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
				</div>

		</div>


	<div class="content">
		<div class="sidenav">

				<a href="viewmessage.php">Messages</a>

      	<a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

      </div>

		<div class="column1">
			<span><strong>Add Drug</strong></span>
			<hr/>
			<div class="entrytable">
				<table cellspacing="2px" padding="10px" class="mytable">
					<form action="inventoryindex1.php" method="post">
						<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: Albendazole"/><input type="text" name="drugname" placeholder="Drug Name" size="30%" /></td></tr>
						<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: 1500"/><input type="text" name="drugquantity" placeholder="Quantity" size="30%" /></td></tr>
						<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: capsules"/><select name="drugcategory" /required><option value="" disabled selected hidden>Choose Drug Category</option>
							<option value="tablets">tablets</option><option value="capsules">capsules</option><option value="syrup">syrup</option><option value="injection">injection</option><option value="other">other</option></select></td></tr>
						<tr><td><img src="icons/info_icon.png" height="12px" width="12px" title="Example: asthma"/><input type="text" name="treats" placeholder="Treats..." size="30%" /></td></tr>
						<tr><td><img src="icons/info_icon.png" height="12px" width="12px" title="Example: 2020/08/10"/><input type="datetime" name="expirydate" placeholder="Expire Date (YYYY-MM-DD)" size="30%" /></td></tr>
						<tr><td><img src="icons/info_icon.png" height="12px" width="12px" title="Example: 1200"/><input type="text" name="initialprice" placeholder="Init Price" size="30%" /></td></tr>
						<tr><td> <img src="icons/info_icon.png" height="12px" width="12px" title="Example: 1500"/><input type="text" name="saleprice" placeholder="Sale Price" size="30%" /></td></tr>
						<tr><td align="center"><input type="submit" name="submitbutn" value="Submit" /></td></tr>
					</form>
				</table>
			</div>
		</div>

	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>
	</body>

</html>
