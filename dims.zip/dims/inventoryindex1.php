<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
	</head>

	<body>
	<div class="main">
    <div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

    <div class="navbar" >

			<a href="adminuser.php" class="navbar">Home</a>

				<div class="dropdown">
					<button class="dropbtn">Drugs</button>
					<div class="dropdownmenu">
						<a href="inventoryform1.php">Add Drugs</a>
						<a href="retrieve1drugs.php">Manage Drugs</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Users</button>
					<div class="dropdownmenu">
						<a href="adduserform.php">Add Users</a>
						<a href="retrieve1users.php">Manage Users</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Prescriptions</button>
					<div class="dropdownmenu">
						<a href="viewprescription1.php">View Prescriptions</a>
					</div>
				</div>

				<a href="report/filter_report.php" class="navbar">Reports</a>

				<div id="username">
					<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
				</div>

		</div>


	<div class="content">
		<div class="sidenav">

				<a href="viewmessage.php">Messages</a>

        <a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

      </div>

		<div class="column1">

			<?php

				//create the connection
				$connection=mysqli_connect("localhost", "root", "", "dit2");

				if(isset($_POST['submitbutn'])) {
					//create the variables
					$drugname=$_POST['drugname'];
					$drugquantity=$_POST['drugquantity'];
					$drugcategory=$_POST['drugcategory'];
					$treats=$_POST['treats'];
					$expirydate=$_POST['expirydate'];
					$initialprice=$_POST['initialprice'];
					$saleprice=$_POST['saleprice'];

		    // checking empty fields
		    if(empty($drugname) || empty($drugquantity) || empty($drugcategory) || empty($treats) || empty($expirydate) || empty($initialprice) || empty($saleprice)) {
		        if(empty($drugname)) {
		            echo "<font color='red'>Drug Name field is empty.</font><br/>";
		        }

		        if(empty($drugquantity)) {
		            echo "<font color='red'>Drug Quantity field is empty.</font><br/>";
		        }

		        if(empty($drugcategory)) {
		            echo "<font color='red'>Drug Category field is empty.</font><br/>";
		        }

						if(empty($treats)) {
		            echo "<font color='red'>Treats... field is empty.</font><br/>";
		        }

		        if(empty($expirydate)) {
		            echo "<font color='red'>Expiry Date field is empty.</font><br/>";
		        }

						if(empty($initialprice)) {
		            echo "<font color='red'>Initial Price field is empty.</font><br/>";
		        }

						if(empty($saleprice)) {
		            echo "<font color='red'>Sale Price field is empty.</font><br/><br/>";
		        }

								header("refresh:7;url=inventoryform1.php");

		    } else {
					//query that will take user data and insert into db
					$query1=mysqli_query($connection, "insert into inventory_list(drugname, drugquantity, drugcategory, treats, expirydate, initialprice, saleprice) values('$drugname', '$drugquantity', '$drugcategory', '$treats', '$expirydate', '$initialprice', '$saleprice')");

					if(!$query1){
						echo "<font color='red'>Drug Entry Unsuccessful.</font> <br/>";
					}
					else{
						echo "<font color='red'>Drug is Successfully Added.</font>";
						header( "refresh:2;url=retrieve1drugs.php" );
					}
		    }
			}
		?>

		</div>

	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>
	</body>

</html>
