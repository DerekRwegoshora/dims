<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
		<link rel="stylesheet" type="text/css" href="style/table.css" />
	</head>

	<body>
	<div class="main">

		<div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

    	<div class="navbar" >

				<a href="adminuser.php" class="navbar">Home</a>

					<div class="dropdown">
						<button class="dropbtn">Drugs</button>
						<div class="dropdownmenu">
							<a href="inventoryform1.php">Add Drugs</a>
							<a href="retrieve1drugs.php">Manage Drugs</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Users</button>
						<div class="dropdownmenu">
							<a href="adduserform.php">Add Users</a>
							<a href="retrieve1users.php">Manage Users</a>
						</div>
					</div>

					<div class="dropdown">
						<button class="dropbtn">Prescriptions</button>
						<div class="dropdownmenu">
							<a href="viewprescription1.php">View Prescriptions</a>
						</div>
					</div>

					<a href="report/filter_report.php" class="navbar">Reports</a>

					<div id="username">
						<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
					</div>

			</div>


		<div class="content">
			<div class="sidenav">

				<a href="viewmessage.php">Messages</a>

        <a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

      </div>

		<div class="column1">
			<span><strong>Add User</strong></span>
			<hr/>
			<div class="entrytable">
				<table cellspacing="2px" padding="10px" class="mytable">
					<form name="form1" action="adduserindex.php" method="post">
						<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: Susan"/><input type="text" name="username" placeholder="Username" /></td></tr>
						<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: 12345"/><input type="password" name="password" placeholder="User Password" /></td></tr>
						<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: susan@yahoo.com"/><input type="email" name="email" placeholder="User Email" /></td></tr>
						<tr><td align="center"><img src="icons/info_icon.png" height="12px" width="12px" title="Example: Admin"/><select name="role" /required><option value="" disabled selected hidden>Choose Role</option>
							<option value="admin">admin</option><option value="normal">normal</option></select>
						</td></tr>
						<tr><td align="center"><input type="submit" name="submitbutn" value="Submit" /></td></tr>
					</form>
				</table>
			</div>
		</div>

	</body>

	<body>
	</div>
		<div class="footer">
			<p>Done by: Derek Rwegoshora</p>
		</div>
	</div>

	</body>

</html>
