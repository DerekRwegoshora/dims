<?php
	session_start();
	if(isset($_SESSION['username'])){
	$user=$_SESSION['username'];
	$state="Admin: $user";
?>

<html>
	<head>
		<title>D.I.M.S</title>
		<link rel="stylesheet" type="text/css" href="style/style.css" />
		<link rel="stylesheet" type="text/css" href="style/table.css" />
	</head>

  <body>
		<div class="main">
		<div class="header">
			<h4>DRUG INVENTORY MANAGEMENT SYSTEM</h4>
		</div>

		<div class="navbar" >

			<a href="adminuser.php" class="navbar">Home</a>

				<div class="dropdown">
					<button class="dropbtn">Drugs</button>
					<div class="dropdownmenu">
						<a href="inventoryform1.php">Add Drugs</a>
						<a href="retrieve1drugs.php">Manage Drugs</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Users</button>
					<div class="dropdownmenu">
						<a href="adduserform.php">Add Users</a>
						<a href="retrieve1users.php">Manage Users</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropbtn">Prescriptions</button>
					<div class="dropdownmenu">
						<a href="viewprescription1.php">View Prescriptions</a>
					</div>
				</div>

				<a href="report/filter_report.php" class="navbar">Reports</a>

				<div id="username">
					<marquee width="60%" behavior="scroll" scrolldelay="150"><?php echo "$state";} ?></marquee>
				</div>

		</div>


	<div class="content">
		<div class="sidenav">

			<a href="viewmessage.php">Messages</a>

			<a href="logout.php"><img src="icons/logout_icon.png" height="12px" width="12px"/><strong> Log Out</strong></a>

		</div>

		<div class="column1">
			<table border="0px" cellpadding="6px" class="sortable">
			<?php
			$conn = mysqli_connect("localhost","root","","dit2");

			echo "<span><strong>Search Results</strong></span><hr/>";
			//search code
			if($_REQUEST['submit']){
			$name = $_POST['name'];

			if(empty($name)){
				echo "<h4>You must type a word to search!</h4>";
			}else{

				$sele = "SELECT * FROM inventory_list WHERE drugname LIKE '%$name%'";
				$result = mysqli_query($conn,$sele);

				if(mysqli_num_rows($result)>0){
				?>
				<tr class="theader"><th>ID</th><th>Name</th><th>Quantity</th><th>Category</th><th>Treats</th><th>Expiry Date</th>
					<th>Initial Price</th><th>Sale Price</th><th>Profit</th><th class="sorttable_nosort">Edit</th><th class="sorttable_nosort">Delete</th></tr>
				<?php
					while($row = mysqli_fetch_assoc($result)){
						$drugindex = $row['drugindex'];
						$drugname = $row['drugname'];
						$drugquantity = $row['drugquantity'];
						$treats = $row['treats'];
						$drugcategory = $row['drugcategory'];
						$expirydate = $row['expirydate'];
						$initialprice = $row['initialprice'];
						$saleprice = $row['saleprice'];
						$profit = $saleprice - $initialprice;
					?>
				<tr>
						<td width="6%"><?php echo "$drugindex"; ?></td>
						<td width="10%"><?php echo "$drugname"; ?></td>
						<td width="10%"><?php echo "$drugquantity"; ?></td>
						<td width="8%"><?php echo "$drugcategory"; ?></td>
						<td width="12%"><?php echo "$treats"; ?></td>
						<td width="10%"><?php echo "$expirydate"; ?></td>
						<td width="10%"><?php echo "$initialprice"; ?></td>
						<td width="10%"><?php echo "$saleprice"; ?></td>
						<td width="10%"><?php echo "$profit"; ?></td>
						<?php echo '<td width="5%"><a href="editdrugs1.php? drugindex=' . $row['drugindex'] . '"><button>Edit</button></a></td> ';?>
						<?php echo '<td width="5%"><a href="deleteinventory1.php? drugindex=' . $row['drugindex'] . '"><button Onclick="return confirmation()">Delete</button></a></td> ';?>
							<script>
								function confirmation() {
								var result = confirm("Are you sure?");
									if (result==true) {
										return true;
								} else {
										return false;
									}
								}
							</script>
						</tr>
								<?php
									}
								}else{
									echo "<h4>No match found!</h4>";
								}
							}
							mysqli_close($conn);
						}
					?>
					</table>
				</div>
			</body>

			<body>
			</div>
				<div class="footer">
					<p>Done by: Derek Rwegoshora</p>
				</div>
			</div>
			</body>

		</html>
