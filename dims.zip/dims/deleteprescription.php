<?php
session_start();
$connection=mysqli_connect("localhost", "root", "", "dit2");

$id=$_GET[id];
$sql="delete from prescription where id='$id'";
mysqli_query($connection, $sql);

//$rows=mysql_fetch_assoc($result);
header("location:viewprescription2.php");
?>
